# localizesenac
Repository for LocalizeSenac Indor Mapping Project

This project it's an attempting to mapping all rooms and areas at my college, to allow users to search and locate any Point of Interest (POI).
 
The main goal is provide information about "where" and "when" the academic events occurs, all that displayed in a intuitive an easy to use dashboard.

Main Features:

- keyword search of POI's;
- Categorized search of POI's;
- Graphical map showing the location of POI;

Additional Features:

- Display additional information about every room or area;
- Show the calendar of academic events;
- Show the course and room for every week day to students;
- Responsive design;



