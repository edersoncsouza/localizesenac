<?php

return array(
    "host"=>"api.zenvia360.com.br",
    "uri"=>array(
        "send"=>"/GatewayIntegration/msgSms.do",
		"query"=>"/GatewayIntegration/msgSms.do",
    ),
);