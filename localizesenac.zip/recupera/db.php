<?php
$connection = mysqli_connect('db_host','db_user','db_password','db_name') or die(mysqli_error($connection));
?>