# php iCloud Calendar
Get, add, edit or remove events in iCloud Calendar

# About
You can get, add/edit or remove your events in your iCloud Calendar. You need your iCloud servername, user id (not Apple ID) and also your calendar id. Check out this amazing php script on https://github.com/muhlba91/icloud to get these informations (also in this repository).

# Requirements
* PHP with cURL extention
* ICS parser by Martin Thoma (http://code.google.com/p/ics-parser/), included in this repository

# How to get started
See example.php
